import controller from "./controller";
import data from "./data";
import ui from "./ui";


function main() {
    ui()
    controller();
    data();
}

export default main;
