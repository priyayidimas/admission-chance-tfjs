import "regenerator-runtime";
import main from "./scripts/main";
import "jquery";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/js/dist/collapse";
import "bootstrap/js/dist/modal";


import "./styles/main.css";



main();